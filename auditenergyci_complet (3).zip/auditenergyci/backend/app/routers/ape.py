from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.database import get_db
from app import models, schemas
from typing import List

router = APIRouter()

@router.get("/{audit_id}", response_model=List[schemas.APEOut])
def get_apes(audit_id: int, db: Session = Depends(get_db)):
    return db.query(models.APE).filter(
        models.APE.audit_id == audit_id
    ).order_by(models.APE.priorite).all()

@router.post("/", response_model=schemas.APEOut)
def create_ape(ape: schemas.APECreate, db: Session = Depends(get_db)):
    db_ape = models.APE(**ape.dict())
    db.add(db_ape)
    db.commit()
    db.refresh(db_ape)
    return db_ape

@router.delete("/{ape_id}")
def delete_ape(ape_id: int, db: Session = Depends(get_db)):
    ape = db.query(models.APE).filter(models.APE.id == ape_id).first()
    if ape:
        db.delete(ape)
        db.commit()
    return {"message": "APE supprimée"}
