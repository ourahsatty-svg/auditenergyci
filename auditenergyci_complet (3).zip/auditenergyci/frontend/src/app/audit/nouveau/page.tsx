'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { auditsAPI } from '@/lib/api'

export default function NouvelAuditPage() {
  const router = useRouter()
  const [form, setForm] = useState({
    nom_entreprise: '', secteur: 'Agroalimentaire', type_site: 'industrie',
    localisation: '', surface_m2: '', nb_employes: '',
    fournisseur_energie: 'CIE', facture_annuelle_fcfa: '',
    consommation_annuelle_kwh: '', type_energie: 'Électricité MT/BT',
    auditeur: '',
  })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const set = (k: string, v: string) => setForm(f => ({ ...f, [k]: v }))

  const submit = async () => {
    if (!form.nom_entreprise) { setError('Le nom de l\'entreprise est obligatoire'); return }
    setLoading(true); setError('')
    try {
      const payload = {
        ...form,
        surface_m2: form.surface_m2 ? parseFloat(form.surface_m2) : null,
        nb_employes: form.nb_employes ? parseInt(form.nb_employes) : null,
        facture_annuelle_fcfa: form.facture_annuelle_fcfa ? parseFloat(form.facture_annuelle_fcfa) : null,
        consommation_annuelle_kwh: form.consommation_annuelle_kwh ? parseFloat(form.consommation_annuelle_kwh) : null,
      }
      const res = await auditsAPI.create(payload)
      router.push(`/audit/${res.data.id}`)
    } catch (e: any) {
      setError(e.response?.data?.detail || 'Erreur lors de la création')
      setLoading(false)
    }
  }

  const inp = (label: string, key: string, type = 'text', placeholder = '') => (
    <div style={{ marginBottom: 14 }}>
      <label style={{ fontSize: 12, fontWeight: 500, color: '#666', display: 'block', marginBottom: 5 }}>{label}</label>
      <input type={type} value={(form as any)[key]} onChange={e => set(key, e.target.value)}
        placeholder={placeholder}
        style={{ width: '100%', padding: '8px 10px', border: '1px solid #e5e5e0', borderRadius: 8, fontSize: 13 }} />
    </div>
  )

  const sel = (label: string, key: string, options: string[]) => (
    <div style={{ marginBottom: 14 }}>
      <label style={{ fontSize: 12, fontWeight: 500, color: '#666', display: 'block', marginBottom: 5 }}>{label}</label>
      <select value={(form as any)[key]} onChange={e => set(key, e.target.value)}
        style={{ width: '100%', padding: '8px 10px', border: '1px solid #e5e5e0', borderRadius: 8, fontSize: 13 }}>
        {options.map(o => <option key={o}>{o}</option>)}
      </select>
    </div>
  )

  const card = (title: string, children: React.ReactNode) => (
    <div style={{ background: '#fff', border: '1px solid #e5e5e0', borderRadius: 12, padding: 20, marginBottom: 16 }}>
      <div style={{ fontWeight: 500, marginBottom: 16, fontSize: 14 }}>{title}</div>
      {children}
    </div>
  )

  return (
    <div style={{ maxWidth: 800 }}>
      <h1 style={{ fontSize: 18, fontWeight: 600, marginBottom: 20 }}>Créer un nouvel audit énergétique</h1>
      {error && <div style={{ padding: '10px 14px', background: '#FCEBEB', color: '#A32D2D', borderRadius: 8, marginBottom: 16, fontSize: 13 }}>{error}</div>}

      {card('Informations générales du site',
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          {inp('Nom de l\'entreprise *', 'nom_entreprise', 'text', 'Ex: SITAB Industries SA')}
          {sel('Secteur d\'activité', 'secteur', ['Agroalimentaire', 'Industrie lourde', 'Tertiaire / Bureaux', 'Santé', 'Télécom', 'Commerce', 'Hôtellerie'])}
          {sel('Type de site (norme applicable)', 'type_site', ['industrie', 'batiment'])}
          {inp('Localisation (ville)', 'localisation', 'text', 'Ex: Yopougon, Abidjan')}
          {inp('Surface (m²)', 'surface_m2', 'number', 'Ex: 12500')}
          {inp('Nombre d\'employés', 'nb_employes', 'number', 'Ex: 240')}
        </div>
      )}

      {card('Données énergétiques initiales',
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          {sel('Fournisseur d\'énergie', 'fournisseur_energie', ['CIE (Compagnie Ivoirienne d\'Électricité)', 'Groupe électrogène', 'Mixte CIE + GE', 'CIEH (hydraulique)'])}
          {sel('Type d\'énergie principale', 'type_energie', ['Électricité MT/BT', 'Gaz naturel', 'Fioul lourd', 'Gasoil', 'Multi-énergie'])}
          {inp('Facture énergétique annuelle (FCFA)', 'facture_annuelle_fcfa', 'number', 'Ex: 180000000')}
          {inp('Consommation annuelle estimée (kWh)', 'consommation_annuelle_kwh', 'number', 'Ex: 2400000')}
        </div>
      )}

      {card('Auditeur responsable',
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          {inp('Auditeur désigné', 'auditeur', 'text', 'Nom et prénom de l\'auditeur')}
        </div>
      )}

      <button onClick={submit} disabled={loading}
        style={{ padding: '10px 24px', background: '#0F6E56', color: '#fff', border: 'none', borderRadius: 8, cursor: loading ? 'not-allowed' : 'pointer', fontSize: 14, opacity: loading ? .7 : 1 }}>
        {loading ? 'Création…' : 'Créer l\'audit et saisir les données terrain →'}
      </button>
    </div>
  )
}
