'use client'
import { useEffect, useState } from 'react'
import { useParams } from 'next/navigation'
import { auditsAPI, equipementsAPI, consommationsAPI, apeAPI, iaAPI, rapportsAPI } from '@/lib/api'

const MOIS = ['', 'Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Jun', 'Jui', 'Aoû', 'Sep', 'Oct', 'Nov', 'Déc']

export default function AuditDetailPage() {
  const { id } = useParams()
  const auditId = Number(id)
  const [audit, setAudit] = useState<any>(null)
  const [tab, setTab] = useState('collecte')
  const [equipements, setEquipements] = useState<any[]>([])
  const [consomm, setConsomm] = useState<any[]>([])
  const [analyse, setAnalyse] = useState<any>(null)
  const [apes, setApes] = useState<any[]>([])
  const [iaMsg, setIaMsg] = useState('')
  const [iaChat, setIaChat] = useState<{ role: string; text: string }[]>([
    { role: 'bot', text: 'Bonjour ! Je suis votre assistant expert en audit énergétique DGE. Posez-moi vos questions sur ce site.' }
  ])
  const [iaLoading, setIaLoading] = useState(false)
  const [genLoading, setGenLoading] = useState(false)
  const [newEquip, setNewEquip] = useState({ categorie: 'moteur', nom: '', puissance_kw: '', heures_an: '', rendement_pct: '', quantite: 1 })

  useEffect(() => {
    auditsAPI.get(auditId).then(r => setAudit(r.data))
    equipementsAPI.list(auditId).then(r => setEquipements(r.data))
    consommationsAPI.list(auditId).then(r => setConsomm(r.data))
    apeAPI.list(auditId).then(r => setApes(r.data))
    auditsAPI.analyse(auditId).then(r => setAnalyse(r.data))
  }, [auditId])

  const addEquipement = async () => {
    if (!newEquip.nom || !newEquip.puissance_kw) return
    const res = await equipementsAPI.create({ ...newEquip, audit_id: auditId, puissance_kw: parseFloat(newEquip.puissance_kw), heures_an: parseFloat(newEquip.heures_an), rendement_pct: newEquip.rendement_pct ? parseFloat(newEquip.rendement_pct) : null })
    setEquipements(e => [...e, res.data])
    setNewEquip({ categorie: 'moteur', nom: '', puissance_kw: '', heures_an: '', rendement_pct: '', quantite: 1 })
  }

  const sendIa = async () => {
    if (!iaMsg.trim()) return
    const msg = iaMsg; setIaMsg(''); setIaLoading(true)
    setIaChat(c => [...c, { role: 'user', text: msg }])
    try {
      const res = await iaAPI.chat(msg, auditId)
      setIaChat(c => [...c, { role: 'bot', text: res.data.response }])
    } catch { setIaChat(c => [...c, { role: 'bot', text: 'Erreur de connexion à l\'IA.' }]) }
    setIaLoading(false)
  }

  const genererAPEs = async () => {
    setGenLoading(true)
    try {
      const res = await iaAPI.genererAPEs(auditId)
      setApes(res.data.apes || [])
    } catch (e) { alert('Erreur génération APE') }
    setGenLoading(false)
  }

  const downloadRapport = async () => {
    const res = await rapportsAPI.generer(auditId)
    const url = URL.createObjectURL(new Blob([res.data]))
    const a = document.createElement('a'); a.href = url
    a.download = `rapport_audit_${audit?.nom_entreprise || auditId}.docx`; a.click()
  }

  const tabs = [
    { key: 'collecte', label: '1. Collecte terrain' },
    { key: 'analyse', label: '2. Analyse énergie' },
    { key: 'ia', label: '3. Assistant IA' },
    { key: 'rapport', label: '4. Rapport DGE' },
  ]

  const inp = (val: string, setter: (v: string) => void, placeholder: string, type = 'text') => (
    <input type={type} value={val} onChange={e => setter(e.target.value)} placeholder={placeholder}
      style={{ padding: '7px 9px', border: '1px solid #e5e5e0', borderRadius: 7, fontSize: 12, width: '100%' }} />
  )

  if (!audit) return <div style={{ padding: 20, color: '#888', fontSize: 13 }}>Chargement…</div>

  return (
    <div>
      <div style={{ marginBottom: 20 }}>
        <h1 style={{ fontSize: 18, fontWeight: 600 }}>{audit.nom_entreprise}</h1>
        <p style={{ fontSize: 13, color: '#888', marginTop: 4 }}>{audit.secteur} · {audit.localisation} · Auditeur : {audit.auditeur}</p>
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', gap: 4, marginBottom: 20, borderBottom: '1px solid #e5e5e0', paddingBottom: 0 }}>
        {tabs.map(t => (
          <button key={t.key} onClick={() => setTab(t.key)}
            style={{ padding: '8px 16px', fontSize: 13, border: 'none', cursor: 'pointer', background: 'transparent', borderBottom: tab === t.key ? '2px solid #0F6E56' : '2px solid transparent', color: tab === t.key ? '#0F6E56' : '#666', fontWeight: tab === t.key ? 500 : 400 }}>
            {t.label}
          </button>
        ))}
      </div>

      {/* TAB 1: COLLECTE */}
      {tab === 'collecte' && (
        <div>
          <div style={{ background: '#fff', border: '1px solid #e5e5e0', borderRadius: 12, padding: 20, marginBottom: 16 }}>
            <div style={{ fontWeight: 500, marginBottom: 14 }}>Équipements du site ({equipements.length})</div>
            {equipements.length > 0 && (
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12, marginBottom: 16 }}>
                <thead><tr style={{ background: '#fafaf8' }}>
                  {['Catégorie', 'Équipement', 'Puissance (kW)', 'H/an', 'Rendement %', 'Conso. kWh/an', ''].map(h => (
                    <th key={h} style={{ textAlign: 'left', padding: '8px 10px', borderBottom: '1px solid #e5e5e0', color: '#888', fontWeight: 500 }}>{h}</th>
                  ))}
                </tr></thead>
                <tbody>
                  {equipements.map((e: any) => (
                    <tr key={e.id} style={{ borderBottom: '1px solid #f5f5f0' }}>
                      <td style={{ padding: '8px 10px' }}>{e.categorie}</td>
                      <td style={{ padding: '8px 10px', fontWeight: 500 }}>{e.nom}</td>
                      <td style={{ padding: '8px 10px' }}>{e.puissance_kw}</td>
                      <td style={{ padding: '8px 10px' }}>{e.heures_an}</td>
                      <td style={{ padding: '8px 10px' }}>{e.rendement_pct || '—'}</td>
                      <td style={{ padding: '8px 10px' }}>{e.consommation_kwh_an ? e.consommation_kwh_an.toLocaleString() : '—'}</td>
                      <td style={{ padding: '8px 10px' }}>
                        <button onClick={() => { equipementsAPI.delete(e.id); setEquipements(eq => eq.filter(x => x.id !== e.id)) }}
                          style={{ fontSize: 11, color: '#A32D2D', border: 'none', background: 'none', cursor: 'pointer' }}>✕</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 8, alignItems: 'end' }}>
              <div>
                <div style={{ fontSize: 11, color: '#888', marginBottom: 4 }}>Catégorie</div>
                <select value={newEquip.categorie} onChange={e => setNewEquip(n => ({ ...n, categorie: e.target.value }))}
                  style={{ padding: '7px 9px', border: '1px solid #e5e5e0', borderRadius: 7, fontSize: 12, width: '100%' }}>
                  {['moteur', 'cvc', 'eclairage', 'chaudiere', 'compresseur', 'groupe_electrogene', 'it_load'].map(c => <option key={c}>{c}</option>)}
                </select>
              </div>
              <div><div style={{ fontSize: 11, color: '#888', marginBottom: 4 }}>Nom</div>{inp(newEquip.nom, v => setNewEquip(n => ({ ...n, nom: v })), 'Ex: Moteur 75kW')}</div>
              <div><div style={{ fontSize: 11, color: '#888', marginBottom: 4 }}>Puissance (kW)</div>{inp(newEquip.puissance_kw, v => setNewEquip(n => ({ ...n, puissance_kw: v })), '75', 'number')}</div>
              <div><div style={{ fontSize: 11, color: '#888', marginBottom: 4 }}>Heures/an</div>{inp(newEquip.heures_an, v => setNewEquip(n => ({ ...n, heures_an: v })), '6500', 'number')}</div>
              <div><div style={{ fontSize: 11, color: '#888', marginBottom: 4 }}>Rendement %</div>{inp(newEquip.rendement_pct, v => setNewEquip(n => ({ ...n, rendement_pct: v })), '88', 'number')}</div>
              <button onClick={addEquipement}
                style={{ padding: '7px 14px', background: '#0F6E56', color: '#fff', border: 'none', borderRadius: 7, cursor: 'pointer', fontSize: 12 }}>
                + Ajouter
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: ANALYSE */}
      {tab === 'analyse' && analyse && (
        <div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12, marginBottom: 20 }}>
            {[
              ['Consommation totale', `${analyse.consommation_totale_kwh?.toLocaleString()} kWh`, 'Annuelle'],
              ['Coût énergétique', `${analyse.cout_total_fcfa?.toLocaleString()} FCFA`, 'Annuel'],
              ['Émissions CO₂', `${analyse.emissions_co2_t} tCO₂`, '/an'],
              ['Intensité éner.', `${analyse.intensite_energetique} kWh/m²`, 'Par m²'],
              ['Potentiel économie', `${analyse.potentiel_economie_kwh?.toLocaleString()} kWh`, '/an (22%)'],
              ['Économie financière', `${analyse.potentiel_economie_fcfa?.toLocaleString()} FCFA`, '/an potentiel'],
            ].map(([l, v, s]) => (
              <div key={l as string} style={{ background: '#f5f5f0', borderRadius: 10, padding: 14, border: '1px solid #e5e5e0' }}>
                <div style={{ fontSize: 11, color: '#888', textTransform: 'uppercase', letterSpacing: '.5px' }}>{l}</div>
                <div style={{ fontSize: 20, fontWeight: 600, color: '#0F6E56', margin: '6px 0 2px' }}>{v}</div>
                <div style={{ fontSize: 11, color: '#888' }}>{s}</div>
              </div>
            ))}
          </div>
          <div style={{ background: '#fff', border: '1px solid #e5e5e0', borderRadius: 12, padding: 20 }}>
            <div style={{ fontWeight: 500, marginBottom: 12 }}>Consommations mensuelles enregistrées</div>
            {consomm.length === 0 ? <p style={{ fontSize: 13, color: '#888' }}>Aucune consommation mensuelle saisie.</p> : (
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
                <thead><tr><th style={{ textAlign: 'left', padding: '8px 10px', borderBottom: '1px solid #e5e5e0', color: '#888' }}>Mois</th><th style={{ textAlign: 'right', padding: '8px 10px', borderBottom: '1px solid #e5e5e0', color: '#888' }}>Électricité (kWh)</th><th style={{ textAlign: 'right', padding: '8px 10px', borderBottom: '1px solid #e5e5e0', color: '#888' }}>Coût (FCFA)</th></tr></thead>
                <tbody>
                  {consomm.map((c: any) => <tr key={c.id}><td style={{ padding: '8px 10px', borderBottom: '1px solid #f5f5f0' }}>{MOIS[c.mois]} {c.annee}</td><td style={{ padding: '8px 10px', borderBottom: '1px solid #f5f5f0', textAlign: 'right' }}>{c.electricite_kwh?.toLocaleString()}</td><td style={{ padding: '8px 10px', borderBottom: '1px solid #f5f5f0', textAlign: 'right' }}>{c.cout_fcfa?.toLocaleString()}</td></tr>)}
                </tbody>
              </table>
            )}
          </div>
        </div>
      )}

      {/* TAB 3: IA */}
      {tab === 'ia' && (
        <div>
          <div style={{ background: '#fff', border: '1px solid #e5e5e0', borderRadius: 12, padding: 20, marginBottom: 16 }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
              <div style={{ fontWeight: 500 }}>Actions d'amélioration énergétique (APE)</div>
              <button onClick={genererAPEs} disabled={genLoading}
                style={{ padding: '7px 14px', background: '#0F6E56', color: '#fff', border: 'none', borderRadius: 8, cursor: 'pointer', fontSize: 12, opacity: genLoading ? .7 : 1 }}>
                {genLoading ? 'Génération IA…' : '🤖 Générer APE avec l\'IA'}
              </button>
            </div>
            {apes.length === 0 ? <p style={{ fontSize: 13, color: '#888' }}>Aucune APE. Cliquez sur "Générer APE avec l'IA" pour lancer l'analyse.</p> :
              apes.map((a: any, i: number) => (
                <div key={i} style={{ border: '1px solid #e5e5e0', borderRadius: 10, padding: 14, marginBottom: 10 }}>
                  <div style={{ fontWeight: 500, marginBottom: 6, fontSize: 13 }}>APE {i + 1} — {a.titre}</div>
                  <p style={{ fontSize: 12, color: '#666', marginBottom: 10 }}>{a.description}</p>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 8 }}>
                    {[
                      ['Éco. énergie', `${(a.economie_kwh_an || 0).toLocaleString()} kWh/an`],
                      ['Éco. financière', `${(a.economie_fcfa_an || 0).toLocaleString()} FCFA`],
                      ['Investissement', `${(a.investissement_fcfa || 0).toLocaleString()} FCFA`],
                      ['ROI', `${a.roi_mois || 0} mois`],
                    ].map(([l, v]) => (
                      <div key={l} style={{ background: '#f5f5f0', padding: '8px 10px', borderRadius: 8, textAlign: 'center' }}>
                        <div style={{ fontSize: 13, fontWeight: 500 }}>{v}</div>
                        <div style={{ fontSize: 10, color: '#888' }}>{l}</div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
          </div>

          <div style={{ background: '#fff', border: '1px solid #e5e5e0', borderRadius: 12, padding: 20 }}>
            <div style={{ fontWeight: 500, marginBottom: 14 }}>Chat avec l'Assistant IA DGE</div>
            <div style={{ maxHeight: 280, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 12 }}>
              {iaChat.map((m, i) => (
                <div key={i} style={{ maxWidth: '85%', alignSelf: m.role === 'user' ? 'flex-end' : 'flex-start', padding: '10px 14px', borderRadius: 12, fontSize: 13, lineHeight: 1.5, background: m.role === 'user' ? '#E1F5EE' : '#f5f5f0', color: m.role === 'user' ? '#085041' : '#333' }}>
                  {m.text}
                </div>
              ))}
              {iaLoading && <div style={{ alignSelf: 'flex-start', padding: '10px 14px', borderRadius: 12, fontSize: 13, background: '#f5f5f0', color: '#888' }}>L'IA analyse…</div>}
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <input value={iaMsg} onChange={e => setIaMsg(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && sendIa()}
                placeholder="Ex: Quelle APE prioriser selon le ROI ?"
                style={{ flex: 1, padding: '8px 12px', border: '1px solid #e5e5e0', borderRadius: 8, fontSize: 13 }} />
              <button onClick={sendIa} disabled={iaLoading}
                style={{ padding: '8px 16px', background: '#0F6E56', color: '#fff', border: 'none', borderRadius: 8, cursor: 'pointer', fontSize: 13, opacity: iaLoading ? .7 : 1 }}>
                Envoyer
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: RAPPORT */}
      {tab === 'rapport' && (
        <div>
          <div style={{ background: '#fff', border: '1px solid #e5e5e0', borderRadius: 12, padding: 20 }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
              <div>
                <div style={{ fontWeight: 500, fontSize: 15 }}>Rapport d'audit — Modèle DGE</div>
                <div style={{ fontSize: 12, color: '#888', marginTop: 4 }}>Conforme EN 16247 / ISO 50002 · Export Word (.docx) modifiable</div>
              </div>
              <button onClick={downloadRapport}
                style={{ padding: '10px 20px', background: '#0F6E56', color: '#fff', border: 'none', borderRadius: 8, cursor: 'pointer', fontSize: 13, fontWeight: 500 }}>
                ↓ Télécharger le rapport DOCX
              </button>
            </div>

            {[
              ['0', 'Page de garde', 'Logo cabinet, nom site, date, numéro rapport DGE'],
              ['1', 'Liste des sigles et abréviations', 'EN 16247, ISO 50002, UES, IPMVP, KPI, CIE, FCFA…'],
              ['2', 'Résumé exécutif', 'Synthèse consommation, potentiel d\'économie, Top APE'],
              ['3', 'Présentation de l\'entreprise', 'Secteur, effectifs, CA, motivations réglementaires CI'],
              ['4', 'Description des installations', 'Inventaire équipements, procédés industriels'],
              ['5', 'Bilan énergétique', 'Consommations mensuelles, coûts, répartition usage'],
              ['6', 'Analyse des usages significatifs (UES)', 'Anomalies, intensité énergétique, benchmarks'],
              ['7', 'Analyse technico-économique', 'Performances actuelles vs normes internationales'],
              ['8', 'Actions d\'amélioration énergétique (APE)', 'Fiches APE : coût, économie, ROI, CO₂ évité'],
              ['9', 'Plan d\'action et calendrier', 'Priorités, jalons, responsables, budget global'],
              ['10', 'Analyse financière et réduction CO₂', 'VAN, TRI, certificats verts, émissions évitées'],
              ['11', 'Conclusion et annexes', 'Relevés de mesure, photos, factures CIE'],
            ].map(([n, title, desc]) => (
              <div key={n} style={{ borderLeft: '2px solid #9FE1CB', paddingLeft: 14, marginBottom: 12 }}>
                <div style={{ fontSize: 11, color: '#0F6E56', fontWeight: 500 }}>Section {n}</div>
                <div style={{ fontSize: 13, fontWeight: 500, marginTop: 2 }}>{title}</div>
                <div style={{ fontSize: 11, color: '#888', marginTop: 2 }}>{desc}</div>
              </div>
            ))}

            <div style={{ marginTop: 16, padding: '10px 14px', background: '#E1F5EE', borderRadius: 8, fontSize: 12, color: '#085041' }}>
              ✓ Rapport généré automatiquement avec python-docx · Format Word .docx entièrement modifiable · Tableaux et graphiques intégrés · Conforme modèle DGE CI
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
