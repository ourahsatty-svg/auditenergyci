'use client'
import { useEffect, useState } from 'react'
import { auditsAPI } from '@/lib/api'

export default function DashboardPage() {
  const [audits, setAudits] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    auditsAPI.list().then(r => { setAudits(r.data); setLoading(false) }).catch(() => setLoading(false))
  }, [])

  const total = audits.length
  const enCours = audits.filter(a => a.statut === 'en_cours').length
  const termines = audits.filter(a => a.statut !== 'en_cours').length

  const card = (label: string, value: string | number, sub?: string, color = '#0F6E56') => (
    <div style={{ background: '#f5f5f0', borderRadius: 10, padding: 16, border: '1px solid #e5e5e0' }}>
      <div style={{ fontSize: 11, color: '#888', textTransform: 'uppercase', letterSpacing: '.5px', marginBottom: 6 }}>{label}</div>
      <div style={{ fontSize: 24, fontWeight: 600, color }}>{value}</div>
      {sub && <div style={{ fontSize: 11, color: '#1D9E75', marginTop: 2 }}>{sub}</div>}
    </div>
  )

  return (
    <div>
      <h1 style={{ fontSize: 18, fontWeight: 600, marginBottom: 20 }}>Tableau de bord — Cabinet d'audit énergétique</h1>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12, marginBottom: 24 }}>
        {card('Audits réalisés', loading ? '…' : total, '+3 ce trimestre')}
        {card('En cours', loading ? '…' : enCours, '2 industries, 3 bâtiments', '#185FA5')}
        {card('Terminés / Validés', loading ? '…' : termines, 'Rapports générés')}
        {card('Économies identifiées', '4 280 MWh', 'Potentiel annuel')}
        {card('Réduction CO₂', '2 140 t', 'Équiv. CO₂/an', '#639922')}
        {card('CA généré', '87 M FCFA', 'Facturé cette année', '#BA7517')}
      </div>

      <div style={{ background: '#fff', border: '1px solid #e5e5e0', borderRadius: 12, padding: 20 }}>
        <div style={{ fontWeight: 500, marginBottom: 14 }}>Derniers audits</div>
        {loading ? <p style={{ color: '#888', fontSize: 13 }}>Chargement…</p> :
          audits.length === 0 ? (
            <p style={{ color: '#888', fontSize: 13 }}>Aucun audit. <a href="/audit/nouveau" style={{ color: '#0F6E56' }}>Créez votre premier audit →</a></p>
          ) : (
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
              <thead>
                <tr>{['Entreprise', 'Secteur', 'Statut', 'Auditeur'].map(h => (
                  <th key={h} style={{ textAlign: 'left', padding: '8px 10px', borderBottom: '1px solid #e5e5e0', color: '#888', fontWeight: 500 }}>{h}</th>
                ))}</tr>
              </thead>
              <tbody>
                {audits.slice(0, 5).map((a: any) => (
                  <tr key={a.id}>
                    <td style={{ padding: '8px 10px', borderBottom: '1px solid #f0f0f0' }}>{a.nom_entreprise}</td>
                    <td style={{ padding: '8px 10px', borderBottom: '1px solid #f0f0f0', color: '#666' }}>{a.secteur}</td>
                    <td style={{ padding: '8px 10px', borderBottom: '1px solid #f0f0f0' }}>
                      <span style={{ padding: '2px 8px', borderRadius: 20, fontSize: 11, background: a.statut === 'valide' ? '#E1F5EE' : '#E6F1FB', color: a.statut === 'valide' ? '#0F6E56' : '#185FA5' }}>
                        {a.statut}
                      </span>
                    </td>
                    <td style={{ padding: '8px 10px', borderBottom: '1px solid #f0f0f0', color: '#666' }}>{a.auditeur}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )
        }
      </div>
    </div>
  )
}
