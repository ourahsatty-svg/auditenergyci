'use client'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { LayoutDashboard, ClipboardList, Plus, BarChart2, FileText, Bot, Zap } from 'lucide-react'

const navItems = [
  { href: '/dashboard', label: 'Tableau de bord', icon: LayoutDashboard },
  { href: '/audits', label: 'Audits réalisés', icon: ClipboardList },
  { href: '/audit/nouveau', label: 'Nouvel audit', icon: Plus },
  { href: '/analyse', label: 'Analyse énergie', icon: BarChart2 },
  { href: '/ia', label: 'Assistant IA', icon: Bot },
  { href: '/rapport', label: 'Rapport DGE', icon: FileText },
]

export default function RootLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname()
  return (
    <html lang="fr">
      <body style={{ margin: 0, fontFamily: 'system-ui, sans-serif', background: '#f5f5f0' }}>
        <div style={{ display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
          {/* Topbar */}
          <header style={{
            height: 52, background: '#fff', borderBottom: '1px solid #e5e5e0',
            display: 'flex', alignItems: 'center', padding: '0 20px', gap: 12, flexShrink: 0
          }}>
            <Zap size={18} color="#0F6E56" />
            <span style={{ fontWeight: 600, fontSize: 15 }}>
              <span style={{ color: '#0F6E56' }}>AuditEnergy</span> CI
            </span>
            <span style={{ flex: 1 }} />
            <span style={{
              fontSize: 11, padding: '3px 10px', borderRadius: 20,
              background: '#E1F5EE', color: '#0F6E56', fontWeight: 500
            }}>DGE Côte d'Ivoire</span>
          </header>

          <div style={{ display: 'flex', flex: 1 }}>
            {/* Sidebar */}
            <nav style={{
              width: 210, background: '#fff', borderRight: '1px solid #e5e5e0',
              padding: '12px 8px', display: 'flex', flexDirection: 'column', gap: 2
            }}>
              {navItems.map(({ href, label, icon: Icon }) => {
                const active = pathname === href || pathname.startsWith(href + '/')
                return (
                  <Link key={href} href={href} style={{ textDecoration: 'none' }}>
                    <div style={{
                      display: 'flex', alignItems: 'center', gap: 8, padding: '8px 10px',
                      borderRadius: 8, cursor: 'pointer',
                      background: active ? '#f5f5f0' : 'transparent',
                      color: active ? '#0F6E56' : '#666',
                      fontWeight: active ? 500 : 400, fontSize: 13
                    }}>
                      <Icon size={15} />
                      {label}
                    </div>
                  </Link>
                )
              })}
            </nav>

            {/* Main content */}
            <main style={{ flex: 1, padding: 24, overflowY: 'auto' }}>
              {children}
            </main>
          </div>
        </div>
      </body>
    </html>
  )
}
