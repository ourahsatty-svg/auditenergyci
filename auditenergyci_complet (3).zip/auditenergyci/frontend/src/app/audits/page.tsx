'use client'
import { useEffect, useState } from 'react'
import { auditsAPI, rapportsAPI } from '@/lib/api'
import Link from 'next/link'

export default function AuditsPage() {
  const [audits, setAudits] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    auditsAPI.list().then(r => { setAudits(r.data); setLoading(false) }).catch(() => setLoading(false))
  }, [])

  const downloadRapport = async (id: number, nom: string) => {
    const res = await rapportsAPI.generer(id)
    const url = URL.createObjectURL(new Blob([res.data]))
    const a = document.createElement('a')
    a.href = url
    a.download = `rapport_audit_${nom}.docx`
    a.click()
  }

  const statut_colors: Record<string, [string, string]> = {
    en_cours: ['#E6F1FB', '#185FA5'],
    termine: ['#FAEEDA', '#BA7517'],
    valide: ['#E1F5EE', '#0F6E56'],
  }

  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
        <h1 style={{ fontSize: 18, fontWeight: 600 }}>Portefeuille d'audits</h1>
        <Link href="/audit/nouveau">
          <button style={{ padding: '8px 16px', background: '#0F6E56', color: '#fff', border: 'none', borderRadius: 8, cursor: 'pointer', fontSize: 13 }}>
            + Nouvel audit
          </button>
        </Link>
      </div>

      <div style={{ background: '#fff', border: '1px solid #e5e5e0', borderRadius: 12, overflow: 'hidden' }}>
        {loading ? <p style={{ padding: 20, color: '#888', fontSize: 13 }}>Chargement…</p> : (
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
            <thead>
              <tr style={{ background: '#fafaf8' }}>
                {['Entreprise', 'Secteur', 'Type', 'Localisation', 'Auditeur', 'Statut', 'Actions'].map(h => (
                  <th key={h} style={{ textAlign: 'left', padding: '10px 12px', borderBottom: '1px solid #e5e5e0', color: '#888', fontWeight: 500 }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {audits.length === 0 ? (
                <tr><td colSpan={7} style={{ padding: 20, textAlign: 'center', color: '#888' }}>
                  Aucun audit. <Link href="/audit/nouveau" style={{ color: '#0F6E56' }}>Créer le premier →</Link>
                </td></tr>
              ) : audits.map((a: any) => {
                const [bg, col] = statut_colors[a.statut] || ['#f5f5f0', '#666']
                return (
                  <tr key={a.id} style={{ borderBottom: '1px solid #f5f5f0' }}>
                    <td style={{ padding: '10px 12px', fontWeight: 500 }}>{a.nom_entreprise}</td>
                    <td style={{ padding: '10px 12px', color: '#666' }}>{a.secteur || '—'}</td>
                    <td style={{ padding: '10px 12px' }}>
                      <span style={{ padding: '2px 8px', borderRadius: 20, fontSize: 11, background: a.type_site === 'industrie' ? '#E6F1FB' : '#FAEEDA', color: a.type_site === 'industrie' ? '#185FA5' : '#BA7517' }}>
                        {a.type_site}
                      </span>
                    </td>
                    <td style={{ padding: '10px 12px', color: '#666' }}>{a.localisation || '—'}</td>
                    <td style={{ padding: '10px 12px', color: '#666' }}>{a.auditeur || '—'}</td>
                    <td style={{ padding: '10px 12px' }}>
                      <span style={{ padding: '2px 8px', borderRadius: 20, fontSize: 11, background: bg, color: col }}>{a.statut}</span>
                    </td>
                    <td style={{ padding: '10px 12px' }}>
                      <div style={{ display: 'flex', gap: 6 }}>
                        <Link href={`/audit/${a.id}`}>
                          <button style={{ padding: '4px 10px', fontSize: 11, border: '1px solid #e5e5e0', borderRadius: 6, cursor: 'pointer', background: '#fff' }}>Voir</button>
                        </Link>
                        <button onClick={() => downloadRapport(a.id, a.nom_entreprise)}
                          style={{ padding: '4px 10px', fontSize: 11, border: '1px solid #1D9E75', borderRadius: 6, cursor: 'pointer', background: '#E1F5EE', color: '#0F6E56' }}>
                          DOCX ↓
                        </button>
                      </div>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        )}
      </div>
    </div>
  )
}
