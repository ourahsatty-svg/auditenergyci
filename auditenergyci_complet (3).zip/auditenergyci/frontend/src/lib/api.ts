import axios from 'axios'

const api = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000',
  headers: { 'Content-Type': 'application/json' },
})

export const auditsAPI = {
  list: () => api.get('/api/audits/'),
  get: (id: number) => api.get(`/api/audits/${id}`),
  create: (data: any) => api.post('/api/audits/', data),
  updateStatut: (id: number, statut: string) => api.put(`/api/audits/${id}/statut?statut=${statut}`),
  analyse: (id: number) => api.get(`/api/audits/${id}/analyse`),
}

export const equipementsAPI = {
  list: (auditId: number) => api.get(`/api/equipements/${auditId}`),
  create: (data: any) => api.post('/api/equipements/', data),
  delete: (id: number) => api.delete(`/api/equipements/${id}`),
}

export const consommationsAPI = {
  list: (auditId: number) => api.get(`/api/consommations/${auditId}`),
  create: (data: any) => api.post('/api/consommations/', data),
  batch: (auditId: number, data: any[]) => api.post(`/api/consommations/batch/${auditId}`, data),
}

export const apeAPI = {
  list: (auditId: number) => api.get(`/api/ape/${auditId}`),
  create: (data: any) => api.post('/api/ape/', data),
  delete: (id: number) => api.delete(`/api/ape/${id}`),
}

export const iaAPI = {
  chat: (message: string, auditId?: number) =>
    api.post('/api/ia/chat', { message, audit_id: auditId }),
  genererAPEs: (auditId: number) =>
    api.post(`/api/ia/generer-apes/${auditId}`),
}

export const rapportsAPI = {
  generer: (auditId: number) =>
    api.get(`/api/rapports/generer/${auditId}`, { responseType: 'blob' }),
}

export default api
